using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance;
    public PlayfabManager playfabManager;
    public Player player;

    void Awake()
    {
        Instance = this;
    }
    void Start()
    {
        playerHighScore = PlayerPrefs.GetFloat("PlayerHighscore", 0);
    }

    public TMP_Text ScoreText;

    public GameObject GameoverPanel;
    public TMP_Text ScoreOnGameOverText;
    public TMP_Text HighScoreOnGameOverText;

    public float PlayerScore = 0;
    private float playerHighScore = 0;

    public void AddAndUpdateScore(float scoreToAdd)
    {
        ManageDifficulty();
        PlayerScore += scoreToAdd;
        ScoreText.text = $"SCORE: {PlayerScore}";
        if (PlayerScore > playerHighScore)
        {
            playerHighScore = PlayerScore;
            PlayerPrefs.SetFloat("PlayerHighscore", PlayerScore);
        }
    }
    void ManageDifficulty()
    {
        if (player.speed < 4)
        {
            player.speed += 0.15f;
        }
    }
    public void OnGameOver()
    {
        GameoverPanel.SetActive(true);
        ScoreOnGameOverText.text = $"SCORE: {PlayerScore}";
        HighScoreOnGameOverText.text = $"HIGHSCORE: {playerHighScore}";
        playfabManager.PostHighScore((int)playerHighScore);
    }
    public void RestartTheGame()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }
}
