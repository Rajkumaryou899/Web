using UnityEngine;

public class Player : MonoBehaviour
{
    public float speed = 5f;
    public float bounceHeight = 2f;
    private Rigidbody rb;
    public Vector3 initialPosition;
    public bool isGameOver = false;
    private bool isMovingDown = true;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        initialPosition = transform.position;
        rb.useGravity = false;
    }
    void Update()
    {
        if (isGameOver) return;

        if (isMovingDown)
        {
            transform.Translate(Vector3.down * speed * Time.deltaTime);
        }
        else if (transform.position.y < initialPosition.y + bounceHeight)
        {
            transform.Translate(Vector3.up * speed * Time.deltaTime);
        }
        else
        {
            isMovingDown = true;
            initialPosition = transform.position;
        }
    }
    void OnCollisionEnter(Collision other)
    {
        if (isGameOver) return;

        if (other.gameObject.CompareTag("Safe"))
        {
            isMovingDown = false;
            initialPosition = transform.position;
        }
        else if (other.gameObject.CompareTag("Danger"))
        {
            isGameOver = true;
            GameManager.Instance?.OnGameOver();
            rb.velocity = Vector3.zero;
        }
    }
}
