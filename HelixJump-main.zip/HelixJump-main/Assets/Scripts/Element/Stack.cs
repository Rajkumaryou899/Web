using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Stack : MonoBehaviour
{
    #region Unity Methods
    void Start()
    {
        // GenerateRandomStack();
    }
    #endregion
    public List<GameObject> stackElements = new List<GameObject>();
    public Material SafeMaterial;
    public Material DangerMaterial;

    //Element 1: empty krne ke liye jisme se ball neeche jayegi
    //Element 2,3: Danger zone keliye jisme se ball neeche nahi jayegi and game over ho jayegi
    public void GenerateRandomStack(bool isFirstStack = false)
    {
        //Element 1: Empty element
        if (isFirstStack)
        {
            foreach (var g in stackElements)
            {
                g.GetComponent<Renderer>().material = SafeMaterial; // Default to safe material
                g.tag = "Safe";
            }
            stackElements[2].SetActive(false);
        }
        else
        {
            //total stacks ki value leni h
            int totalStacksTillNow = (int)GameManager.Instance.PlayerScore / 10;
            int difficultyLevel = totalStacksTillNow / 3;
            //difficulty level is 0 or 1 = 1 danger element
            //difficulty is 2 = 1, 2 danger element
            //difficulty is 3 = 2,3 danger elements
            //difficulty is >=4 => 2,3,4 danger elements
            int totalDangerElementsCount;
            if (difficultyLevel == 0 || difficultyLevel == 1)
            {
                totalDangerElementsCount = Random.Range(1, 3);//1,2
            }
            else if (difficultyLevel == 2)
            {
                totalDangerElementsCount = Random.Range(1, 3);//1,2
            }
            else if (difficultyLevel == 3)
            {
                totalDangerElementsCount = Random.Range(2, 4);//2,3
            }
            else
            {
                totalDangerElementsCount = Random.Range(2, 5);//2,3,4
            }
            int emptyElementIndex = Random.Range(0, stackElements.Count);
            List<int> dangerElementIndicesList = new List<int>();
            for (int i = 0; i < totalDangerElementsCount; i++)
            {
                int foundIndex;
                do
                {
                    foundIndex = Random.Range(0, stackElements.Count);
                }
                while (foundIndex == emptyElementIndex || dangerElementIndicesList.Contains(foundIndex));
                dangerElementIndicesList.Add(foundIndex);
            }


            foreach (var g in stackElements)
            {
                g.GetComponent<Renderer>().material = SafeMaterial; // Default to safe material
                g.tag = "Safe";
            }

            stackElements[emptyElementIndex].SetActive(false);

            foreach (int index in dangerElementIndicesList)
            {
                stackElements[index].GetComponent<Renderer>().material = DangerMaterial;
                stackElements[index].tag = "Danger";
                stackElements[index].GetComponent<Renderer>().material = DangerMaterial;
                stackElements[index].tag = "Danger";
            }
        }

    }
}